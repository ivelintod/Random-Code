from distutils.core import setup


setup(
    name='CinemaReservationSystem',
    version='0.1dev',
    packages=['CRS',],
)
