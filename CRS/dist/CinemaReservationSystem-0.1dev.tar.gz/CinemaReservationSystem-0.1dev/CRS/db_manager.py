import sqlite3
from settings import DB_NAME


class Manager:

    DEFAULT_NUM_SEATS = 100

    def __init__(self):
        self.db = sqlite3.connect(DB_NAME)
        self.cursor = self.db.cursor()

    def show_movies(self):
        script = 'SELECT * FROM MOVIES ORDER BY rating'
        self.cursor.execute(script)
        movies = (row for row in self.cursor)
        return movies

    def show_movie_projections(self, movie_id, date=None):
        if date:
            script = 'SELECT * FROM PROJECTIONS WHERE movie_id=?, date=? ORDER BY date'
            self.cursor.execute(script, (movie_id, date,))
        else:
            script = 'SELECT * FROM PROJECTIONS WHERE movie_id=?'
            self.cursor.execute(script, (movie_id,))

    def show_number_of_seats(self, projection_id):
        script = 'SELECT COUNT(*) FROM RESERVATIONS WHERE projection_id=?'
        self.cursor.execute(script, (projection_id,))
        return self.DEFAULT_NUM_SEATS - int([row for row in self.cursor][0][0])



