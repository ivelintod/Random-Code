DB_NAME = 'movie_database.db'
SQL_COMMANDS = 'fill_db.sql'
