import sqlite3
import os
import sys
from settings import DB_NAME, SQL_COMMANDS


def create_db(path):
    path += '/'
    if os.path.exists(path + DB_NAME):
        os.remove(path + DB_NAME)

    conn = sqlite3.connect(path + DB_NAME)
    c = conn.cursor()
    with open(SQL_COMMANDS) as info:
        script = info.read()
        c.executescript(script)


if __name__ == '__main__':
    create_db(sys.argv[1])
